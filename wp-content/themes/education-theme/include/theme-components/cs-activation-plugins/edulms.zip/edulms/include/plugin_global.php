<?php
global $cs_course_options;
$cs_course_options = get_option('cs_course_options');
$cs_course_options['cs_dashboard']=isset($cs_course_options['cs_dashboard']) ? $cs_course_options['cs_dashboard']:'';
$cs_course_options['cs_review_status']=isset($cs_course_options['cs_review_status']) ? $cs_course_options['cs_review_status']:'';
$cs_course_options['cs_currency_symbol']=isset($cs_course_options['cs_currency_symbol']) ? $cs_course_options['cs_currency_symbol']:'';
$cs_course_options['action']=isset($cs_course_options['action']) ? $cs_course_options['action']:'';
$cs_course_options['cs_dashboard']=isset($cs_course_options['cs_dashboard']) ? $cs_course_options['cs_dashboard']:'';
$cs_course_options['cs_review_status']=isset($cs_course_options['cs_review_status']) ? $cs_course_options['cs_review_status']:'';
$cs_course_options['cs_currency_symbol']=isset($cs_course_options['cs_currency_symbol']) ? $cs_course_options['cs_currency_symbol']:'';
$cs_course_options['action']=isset($cs_course_options['action']) ? $cs_course_options['action']:'';